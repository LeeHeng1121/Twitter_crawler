#!/usr/bin/env bash -l
export Broker=PeterPi

exports.keyinfo = {
      consumer_key: 'P1b80gDn6iP41uGPdXfQo0c1C',
      consumer_secret: 'TGuYrPQzBIZBBP4ru9Cs6H4Xx0itn6z6hKB0KVtBLelQTnFYBI',
      access_token_key: '2542468963-amwZFTLSYyTGZ9uNdoecNi6YVSVT6nqm8ZiX92S',
      access_token_secret: 'uJWpJuihqWtAUSQtAn7rjKSvvY9x4ZnpJZcjy7NurOACF'
};

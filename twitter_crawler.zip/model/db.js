var mongoose = require('mongoose');
var Schema = mongoose.Schema;


mongoose.connect('mongodb://127.0.0.1:27017/AizuLab-TwitterStream');
exports.connection = mongoose.connection;


exports.Tweet = mongoose.model('Tweet',{
    "created_at":Date,
    "id":Number,
    "text":String,
    "source":{},
    "truncated":{},
    "in_reply_to_status_id":{},
    "in_reply_to_user_id":{},
    "in_reply_to_screen_name":{},
    "user":{},
     "geo": {},
     "coordinates": {},
     "place": {},
     "is_quote_status": {},
     "retweet_count": {},
     "favorite_count": {},
     "entities":{},
     "extended_entities": {},
     "favorited": {},
     "retweeted": {},
     "possibly_sensitive": {},
     "filter_level": {},
     "lang": {},
     "timestamp_ms": Date
});

var kafka = require('./kafka.js');
var consumer = new kafka.kafka.Consumer(kafka.client,[{ topic: kafka.topic} ],{autoCommit: true});

consumer.on('message', function (message) {
    console.log(message.value);
});

consumer.on('error',function(err){
    if(err){throw err;}
});

var kafkaNode = process.env.Broker+"+:2181";
var NodeName = "kafka-twitter";

console.log(process.env.Broker);

require('events').EventEmitter.prototype._maxListeners = 10000;

var topic = "twitter";


var kafka = require('kafka-node'),
    Producer = kafka.Producer,
    client = new kafka.Client(kafkaNode,NodeName),
    producer = new Producer(client);

exports.startProducer = function startProducer(callback) {
    producer.on('ready', function () {
        callback(producer);
    });
    producer.on('error', function (err) {
        if(err) throw err;
    });
}

exports.topic = topic;
exports.kafka = kafka;
exports.client = client;
